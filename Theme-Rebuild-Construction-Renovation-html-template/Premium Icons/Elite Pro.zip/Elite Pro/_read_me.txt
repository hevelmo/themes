Picto Foundry Elite Pro
website: http://pictofoundry.com 
twitter: @pictofoundry
created by: Cory Shoaf & Tyler Wanlass


---

Thanks for purchasing Picto Foundry Elite Pro.

ELITE PRO LICENSE: 

Icons and web fonts are provided as-is without any express or implied warranty.

ALLOWED
-Use PictoFoundry Icon fonts, Vectors and PNGs for personal and commercial projects royalty-free, WITHOUT attribution.
-Up to 5 users is allowed to use the icons.
-Change the shape, size, color or style of icons based the terms of this agreement.
-You may resell, rebrand or transfer icons as part of a theme or template.

RESTRICTIONS
-You may NOT embed vectors on any website and may not be made available for download or transfer.
-You may not rebrand Elite Pro as an icon pack or bundle without the written consent from 34 Orange LLC.


Help & Getting Started:

http://www.pictofoundry.com/help
http://www.pictofoudnry.com/gettin-started


Contact us at support@pictofoundry.com with questions or comments on payments/licensing issues.



PictoFoundry is a product of 34 Orange LLC
 